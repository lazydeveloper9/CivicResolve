// src/screens/ProfileScreen.tsx
import React, { useContext } from 'react';
import { View, Text, StyleSheet, Button, ActivityIndicator } from 'react-native';
import { AuthContext } from './AuthContext';

const ProfileScreen = () => {
  const { user, logout, isLoading } = useContext(AuthContext);

  if (isLoading) {
    return <ActivityIndicator size="large" style={styles.container} />;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Profile</Text>
      {user ? (
        <View style={styles.detailsContainer}>
          <View style={styles.row}>
            <Text style={styles.label}>Name:</Text>
            <Text style={styles.value}>{user.name}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Email:</Text>
            <Text style={styles.value}>{user.email}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Age:</Text>
            <Text style={styles.value}>{user.age}</Text>
          </View>
        </View>
      ) : (
        <Text>Could not load user profile.</Text>
      )}
      <View style={styles.logoutButton}>
        <Button title="Logout" onPress={logout} color="#ff3b30" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  detailsContainer: {
    width: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingBottom: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: '500',
    color: '#333',
  },
  value: {
    fontSize: 18,
    color: '#555',
  },
  logoutButton: {
    marginTop: 30,
    width: '80%',
  },
});

export default ProfileScreen;