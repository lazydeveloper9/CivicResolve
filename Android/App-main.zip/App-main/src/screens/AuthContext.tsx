// src/context/AuthContext.tsx
import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SERVER_IP = 'http://10.11.231.68:3000'; // Centralize your server IP

interface User {
  id: number;
  email: string;
  name: string;
  age: number;
}

interface AuthContextData {
  userToken: string | null;
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string, age: number) => Promise<void>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [userToken, setUserToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUserProfile = async (token: string) => {
    try {
      console.log('Fetching profile with token:', token);
      const response = await fetch(`${SERVER_IP}/api/profile`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      });

      console.log('Profile response status:', response.status);
      const userData = await response.json();
      console.log('Profile response data:', userData);

      if (response.ok) {
        setUser(userData);
      } else {
        if (response.status === 401 || response.status === 403) {
          // Token is invalid or expired
          await logout();
          throw new Error('Session expired. Please login again.');
        } else {
          throw new Error(userData.error || 'Failed to fetch user profile.');
        }
      }
    } catch (error) {
      console.error('fetchUserProfile error:', error);
      if (error instanceof Error) {
        console.error('Error details:', error.message);
      }
      await logout();
      throw error; // Re-throw to handle in the calling function
    }
  };

  const signup = async (email: string, password: string, name: string, age: number) => {
    const response = await fetch(`${SERVER_IP}/api/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name, age }),
    });

    const data = await response.json();

    if (!response.ok) {
      // The server provides a specific error message (e.g., email already exists)
      throw new Error(data.error || 'Signup failed');
    }
  };

  const login = async (email: string, password: string) => {
    const response = await fetch(`${SERVER_IP}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Login failed');
    }

    if (data.token) {
      setUserToken(data.token);
      await AsyncStorage.setItem('userToken', data.token);
      await fetchUserProfile(data.token);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    setUserToken(null);
    setUser(null);
    await AsyncStorage.removeItem('userToken');
    setIsLoading(false);
  };

  const isLoggedIn = async () => {
    try {
      setIsLoading(true);
      const token = await AsyncStorage.getItem('userToken');
      setUserToken(token);
      if (token) {
        await fetchUserProfile(token);
      }
      setIsLoading(false);
    } catch (e) {
      console.log(`isLoggedIn error ${e}`);
    }
  };

  useEffect(() => {
    isLoggedIn();
  }, []);

  return (
    <AuthContext.Provider value={{ login, signup, logout, userToken, user, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};