// src/screens/HomeScreen.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import FloatingButton from '../components/FloatingButton';
import MediaListScreen from '../components/MediaListingScreen';
import LocationSaver from '../components/LocationSaver';

const HomeScreen = () => {
  return (
    <View style={styles.container}>
      <MediaListScreen />
      <FloatingButton/>
      {/* <LocationSaver/> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
    // alignItems: 'center',
  },
});

export default HomeScreen;