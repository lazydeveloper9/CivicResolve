import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Modal,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Pressable,
  Platform,
  PermissionsAndroid,
  ActivityIndicator,
  findNodeHandle,
  UIManager,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Geolocation from 'react-native-geolocation-service';

const ISSUE_TYPES = [
  { label: 'Electricity', value: 'electricity' },
  { label: 'Road', value: 'road' },
  { label: 'Water', value: 'water' },
  { label: 'Garbage', value: 'garbage' },
  { label: 'Street Light', value: 'street_light' },
  { label: 'Public Safety', value: 'safety' },
  { label: 'Environment', value: 'environment' },
  { label: 'Others', value: 'others' },
];

interface MediaUploadModalProps {
  visible: boolean;
  onClose: () => void;
  onSubmit: (details: {
    description: string;
    location: string;
    datetime: string;
    issueType: string;
  }) => void;
}

const MediaUploadModal = ({ visible, onClose, onSubmit }: MediaUploadModalProps) => {
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [datetime] = useState(new Date().toLocaleString());
  const [issueType, setIssueType] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isFetchingLocation, setIsFetchingLocation] = useState(false);

  // For portal dropdown positioning
  const buttonRef = useRef<any>(null);
  const [buttonLayout, setButtonLayout] = useState<{ x: number; y: number; width: number; height: number }>({
    x: 0,
    y: 0,
    width: 0,
    height: 0,
  });

  const measureButton = (tries = 0) => {
    if (!buttonRef.current) {
      // try again briefly if ref not ready
      if (tries < 5) setTimeout(() => measureButton(tries + 1), 50);
      return;
    }

    // prefer measureInWindow
    if (typeof buttonRef.current.measureInWindow === 'function') {
      buttonRef.current.measureInWindow((x: number, y: number, width: number, height: number) => {
        setButtonLayout({ x, y, width, height });
      });
    } else {
      // fallback using UIManager.measure
      const handle = findNodeHandle(buttonRef.current);
      if (!handle) return;
      UIManager.measure(handle, (_fx, _fy, width, height, px, py) => {
        setButtonLayout({ x: px, y: py, width, height });
      });
    }
  };

  useEffect(() => {
    if (isDropdownOpen) {
      // measure after a tick so layout has settled
      setTimeout(() => measureButton(), 50);
    }
  }, [isDropdownOpen]);

  const handleGetCurrentLocation = async () => {
    setIsFetchingLocation(true);

    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
          Alert.alert('Permission Denied');
          setIsFetchingLocation(false);
          return;
        }
      }

      Geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;

          try {
            const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;

            const response = await fetch(url, {
              headers: {
                'User-Agent': 'CivicIssueTracker/1.0 (ykn972006@gmail.com)',
              },
            });

            if (!response.ok) {
              const errorText = await response.text();
              throw new Error(`Status: ${response.status}. Message: ${errorText}`);
            }

            const json = await response.json();
            if (!json.address) throw new Error('Could not find address details in the response.');

            const city = json.address.city || json.address.town || json.address.village;
            const road = json.address.road;
            const suburb = json.address.suburb;
            const formattedLocation = [road, suburb, city].filter(Boolean).join(', ');

            if (formattedLocation) setLocation(formattedLocation);
            else Alert.alert('Location Not Found', 'Could not determine a location name.');
          } catch (error) {
            console.error('[LOCATION] Error during reverse geocoding:', error);
            Alert.alert('Network Error', 'Failed to fetch city name. Please try again.');
          } finally {
            setIsFetchingLocation(false);
          }
        },
        (error) => {
          console.error('[LOCATION] Geolocation.getCurrentPosition Error:', error);
          Alert.alert('Geolocation Error', `Code: ${error.code}, Message: ${error.message}`);
          setIsFetchingLocation(false);
        },
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 }
      );
    } catch (err) {
      console.error('[LOCATION] Outer try/catch error:', err);
      setIsFetchingLocation(false);
    }
  };

  const handleSubmit = () => {
    if (!description.trim() || !location.trim() || !issueType) {
      Alert.alert('Error', 'Please fill out all fields.');
      return;
    }
    onSubmit({ description: description.trim(), location: location.trim(), datetime, issueType });
    setDescription('');
    setLocation('');
    setIssueType('');
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} onPress={(e) => e.stopPropagation()}>
          <View style={styles.modalContent}>
            <View style={styles.header}>
              <Text style={styles.title}>Add Media Details</Text>
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <Ionicons name="close" size={24} color="#000" />
              </TouchableOpacity>
            </View>

            <View style={styles.formContainer}>
              <ScrollView style={styles.form} showsVerticalScrollIndicator={false} nestedScrollEnabled>
                <Text style={styles.label}>Description</Text>
                <TextInput
                  style={[styles.input, { minHeight: 80 }]}
                  placeholder="Add a description..."
                  value={description}
                  onChangeText={setDescription}
                  multiline
                  placeholderTextColor="gray"
                />

                <Text style={styles.label}>Issue Type</Text>
                <View style={styles.dropdownContainer}>
                  <Pressable
                    ref={buttonRef}
                    style={styles.dropdownButton}
                    onPress={() => {
                      // Toggle dropdown portal
                      setIsDropdownOpen((v) => !v);
                    }}
                  >
                    <Text style={styles.dropdownButtonText}>
                      {issueType ? ISSUE_TYPES.find((t) => t.value === issueType)?.label : 'Select Issue Type'}
                    </Text>
                    <Ionicons name={isDropdownOpen ? 'chevron-up' : 'chevron-down'} size={24} color="#666" />
                  </Pressable>
                </View>

                <View style={styles.labelContainer}>
                  <Text style={styles.label}>Location</Text>
                  <TouchableOpacity onPress={handleGetCurrentLocation} disabled={isFetchingLocation}>
                    {isFetchingLocation ? (
                      <ActivityIndicator size="small" color="#6200ee" />
                    ) : (
                      <View style={styles.getLocationButton}>
                        <Ionicons name="location-sharp" size={16} color="#6200ee" />
                        <Text style={styles.getLocationButtonText}>Use My Location</Text>
                      </View>
                    )}
                  </TouchableOpacity>
                </View>

                <TextInput
                  style={styles.input}
                  placeholder="Enter location or use current"
                  value={location}
                  onChangeText={setLocation}
                  placeholderTextColor="gray"
                />

                <Text style={styles.label}>Date & Time</Text>
                <Text style={styles.datetime}>{datetime}</Text>
              </ScrollView>

              <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
                  <Text style={styles.submitButtonText}>Upload Media</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </TouchableOpacity>

      {/* Portal-style dropdown Modal */}
      <Modal visible={isDropdownOpen} transparent animationType="none" onRequestClose={() => setIsDropdownOpen(false)}>
        <TouchableOpacity
          style={styles.portalOverlay}
          activeOpacity={1}
          onPress={() => setIsDropdownOpen(false)}
        >
          {/* Dropdown box positioned under button */}
          <View
            style={[
              styles.portalDropdown,
              {
                top: buttonLayout.y + buttonLayout.height,
                left: buttonLayout.x,
                width: Math.max(buttonLayout.width, 200),
                maxHeight: 260,
              },
            ]}
            pointerEvents="box-none"
          >
            <ScrollView
              nestedScrollEnabled={false}
              showsVerticalScrollIndicator
              keyboardShouldPersistTaps="handled"
              bounces={false}
            >
              {ISSUE_TYPES.map((type) => (
                <TouchableOpacity
                  key={type.value}
                  style={[styles.dropdownItem, issueType === type.value && styles.dropdownItemSelected]}
                  onPress={() => {
                    setIssueType(type.value);
                    setIsDropdownOpen(false);
                  }}
                >
                  <Text style={[styles.dropdownItemText, issueType === type.value && styles.dropdownItemTextSelected]}>
                    {type.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  portalOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  portalDropdown: {
    position: 'absolute',
    // top/left/width set dynamically
    backgroundColor: '#fff',
    borderRadius: 8,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    overflow: 'hidden',
    zIndex: 9999,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    paddingTop: 20,
    paddingHorizontal: 16,
    width: 350,
    height: 600,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingHorizontal: 4,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  closeButton: {
    padding: 8,
  },
  formContainer: {
    flex: 1,
    height: 400,
    maxHeight: 600,
  },
  form: {
    flex: 1,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
    paddingHorizontal: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    color: '#000',
    backgroundColor: '#fff',
    textAlignVertical: 'top',
    minHeight: 40,
  },
  datetime: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
  },
  labelContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  getLocationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    backgroundColor: '#f0eaff',
  },
  getLocationButtonText: {
    color: '#6200ee',
    fontWeight: 'bold',
    marginLeft: 6,
    fontSize: 12,
  },

  dropdownContainer: {
    position: 'relative',
    zIndex: 1000,
    elevation: 5,
    marginBottom: 12,
  },
  dropdownButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
  },
  dropdownButtonText: {
    fontSize: 16,
    color: '#333',
  },

  dropdownItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  dropdownItemSelected: {
    backgroundColor: '#f0f0f0',
  },
  dropdownItemText: {
    fontSize: 16,
    color: '#333',
  },
  dropdownItemTextSelected: {
    color: '#6200ee',
    fontWeight: 'bold',
  },

  buttonContainer: {
    paddingVertical: 16,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  submitButton: {
    backgroundColor: '#6200ee',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default MediaUploadModal;
