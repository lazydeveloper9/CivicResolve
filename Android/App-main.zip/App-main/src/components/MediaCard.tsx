// MediaCard.tsx
import React from 'react';
import { View, StyleSheet, Image, Text } from 'react-native';
import Video from 'react-native-video';
import Ionicons from 'react-native-vector-icons/Ionicons';

interface MediaItem {
  name: string;
  path: string;
  url: string;
  type: 'image' | 'video';
  description: string;
  location: string;
  datetime: string;
  contributor: string;
  issue_type?: string;
}

const MediaCard = ({ item }: { item: MediaItem }) => {
  const uri = item.url;

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.contributorContainer}>
          <Ionicons name="person-circle-outline" size={24} color="#6200ee" />
          <Text style={styles.contributor}>{item.contributor || 'Anonymous'}</Text>
        </View>
        <View style={styles.locationContainer}>
          <Text style={styles.location}>{item.location}</Text>
          <Ionicons name="location" size={20} color="#6200ee" />
        </View>
      </View>

      {item.type === 'video' ? (
        <Video
          source={{ uri }}
          style={styles.media}
          controls={true}
          paused={true}
          resizeMode="cover"
        />
      ) : (
        <Image
          source={{ uri }}
          style={styles.media}
          resizeMode="cover"
        />
      )}

      <View style={styles.detailsContainer}>
        {/* <Text style={styles.filename}>{item.name}</Text> */}
        
        <View style={styles.dateContainer}>
          <Ionicons name="time-outline" size={16} color="#666" />
          <Text style={styles.datetime}>{item.datetime || 'No date available'}</Text>
        </View>

        <Text style={styles.descriptionLabel}>Description</Text>
        <Text style={styles.description}>{item.description || 'No description provided'}</Text>
        <Text style={styles.description}>{item.issue_type ? `Issue Type: ${item.issue_type}` : 'No issue type provided'}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    margin: 8,
    width: '96%',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  contributorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contributor: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
    color: '#333',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  location: {
    fontSize: 14,
    color: '#666',
    marginRight: 4,
  },
  media: {
    width: '100%',
    height: 400,
  },
  detailsContainer: {
    padding: 12,
  },
  filename: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  datetime: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  descriptionLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 6,
  },
  description: {
    fontSize: 14,
    color: '#444',
    lineHeight: 20,
  },
});

export default MediaCard;