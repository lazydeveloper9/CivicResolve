import React, { useState } from 'react';
import {
  View,
  Button,
  Text,
  Alert,
  Platform,
  PermissionsAndroid,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import AsyncStorage from '@react-native-async-storage/async-storage'; // Or your preferred storage

// ❗ IMPORTANT: Use your computer's local network IP address
const API_URL = 'http://10.11.231.68:3000'; 

const LocationSaver = () => {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('Ready to get your location.');

  const handleGetAndSaveLocation = async () => {
    setLoading(true);
    setStatus('Requesting permission...');

    // 1. Get Location Permission
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location Permission',
          message: 'This app needs your location to determine your city.',
          buttonPositive: 'OK',
        },
      );
      if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
        Alert.alert('Permission Denied', 'Location permission is required.');
        setLoading(false);
        return;
      }
    }

    // 2. Get GPS Coordinates
    setStatus('Fetching coordinates...');
    Geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setStatus('Coordinates found. Getting city...');
        
        // 3. Convert Coordinates to City Name (Reverse Geocoding)
        try {
          const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`;
          const response = await fetch(url);
          const json = await response.json();
          const city = json.address.city || json.address.town || json.address.village;

          if (!city) {
            throw new Error('Could not determine city from coordinates.');
          }
          
          setStatus(`City found: ${city}. Saving...`);

          // 4. Save City to Your Backend
          await saveCityToBackend(city);

        } catch (error) {
          console.error('Geocoding or saving error:', error);
          setStatus(`Error: ${(error as Error).message}`);
          Alert.alert('Error', 'Could not process your location. Please try again.');
          setLoading(false);
        }
      },
      (error) => {
        setStatus('Error getting location.');
        Alert.alert('Location Error', error.message);
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 1000 },
    );
  };

interface SaveLocationResponse {
    error?: string;
    // Add other expected response properties here
}

interface LocationError {
    message: string;
}

const saveCityToBackend = async (cityName: string): Promise<void> => {
    // ❗ You MUST retrieve the token you saved after the user logged in.
    const token = await AsyncStorage.getItem('userToken'); 

    if (!token) {
            Alert.alert('Not Authenticated', 'You must be logged in to save your location.');
            setLoading(false);
            return;
    }

    try {
        const response = await fetch(`${API_URL}/api/location`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`, // Include the auth token!
            },
            body: JSON.stringify({ cityName }),
        });

        const result: SaveLocationResponse = await response.json();

        if (!response.ok) {
            throw new Error(result.error || 'Failed to save location.');
        }
        
        setStatus(`Successfully saved "${cityName}" to your profile!`);
        Alert.alert('Success!', `Your location (${cityName}) has been saved.`);

    } catch (error: unknown) {
        const err = error as LocationError;
        console.error('API Error:', err);
        setStatus(`Error: ${err.message}`);
        Alert.alert('Server Error', `Could not save location: ${err.message}`);
    } finally {
        setLoading(false);
    }
};


  return (
    <View style={styles.container}>
      <Text style={styles.statusText}>{status}</Text>
      {loading ? (
        <ActivityIndicator size="large" color="#007BFF" />
      ) : (
        <Button
          title="Get My City & Save"
          onPress={handleGetAndSaveLocation}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 8,
        margin: 15,
    },
    statusText: {
        marginBottom: 15,
        fontSize: 16,
        textAlign: 'center',
        color: '#333',
    }
})

export default LocationSaver;