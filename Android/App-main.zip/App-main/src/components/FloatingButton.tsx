import { View, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import React, { useState, useContext } from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { launchCamera, Asset } from 'react-native-image-picker';
import MediaUploadModal from './MediaUploadModal';
import { AuthContext } from '../screens/AuthContext';
import ImageResizer from 'react-native-image-resizer';

// Server configuration
const SERVER_URL = 'http://10.11.231.68:3000';
// import { CameraRoll } from '@react-native-camera-roll/camera-roll';

const FloatingButton = () => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [currentAsset, setCurrentAsset] = useState<Asset | null>(null);

  const handleCameraPress = () => {
    launchCamera({ mediaType: 'photo' }, async (response) => {
      if (response.assets && response.assets[0]) {
        const asset = response.assets[0];
        // Compress only if it's an image
        if (asset.type && asset.type.startsWith('image/')) {
          try {
            if (!asset.uri) {
              throw new Error('No image URI available');
            }
            const resizedImage = await ImageResizer.createResizedImage(
              asset.uri,
              1024, // max width
              1024, // max height
              'JPEG', // format
              70 // quality (0-100)
            );
            // Use resizedImage.uri for upload
            setCurrentAsset({
              ...asset,
              uri: resizedImage.uri,
              fileName: resizedImage.name || asset.fileName,
              fileSize: resizedImage.size || asset.fileSize,
            });
          } catch (err) {
            console.warn('Image compression failed:', err);
            setCurrentAsset(asset); // fallback to original
          }
        } else {
          setCurrentAsset(asset);
        }
        setIsModalVisible(true);
      }
    });
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
    setCurrentAsset(null);
  };

  const { userToken } = useContext(AuthContext);

  const handleUpload = async (details: { description: string; location: string; datetime: string; issueType: string }) => {
    if (!currentAsset) {
      Alert.alert('Error', 'No media selected');
      return;
    }

    if (!userToken) {
      Alert.alert('Error', 'Please log in to upload media');
      return;
    }

    // Create form data
    const formData = new FormData();
    
    // Append the media file with correct type
    const fileType = currentAsset.type || 'image/jpeg';
    const fileName = currentAsset.fileName || `media-${Date.now()}.jpg`;
    
    formData.append('media', {
      uri: currentAsset.uri,
      type: fileType,
      name: fileName,
    });
    
    // Append the additional details
    formData.append('description', details.description);
    formData.append('location', details.location);
    formData.append('datetime', details.datetime);
    formData.append('issueType', details.issueType);

    console.log('Uploading media with details:', {
      uri: currentAsset.uri,
      type: fileType,
      name: fileName,
      description: details.description,
      location: details.location,
      datetime: details.datetime,
      issueType: details.issueType
    });

    try {
      const res = await fetch(`${SERVER_URL}/upload`, {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'multipart/form-data',
          'Accept': 'application/json',
        },
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => null);
        console.error('Upload failed:', { status: res.status, errorData });
        throw new Error(
          errorData?.error || errorData?.details || 'Failed to upload media'
        );
      }

      const result = await res.json();
      console.log('Upload success:', result);
      
      Alert.alert(
        'Success',
        'Media uploaded successfully!',
        [{ text: 'OK', onPress: handleCloseModal }]
      );
    } catch (error) {
      console.error('Upload Error:', error);
      
      // More detailed error message to help debugging
      const errorMessage = error instanceof Error 
        ? `Upload failed: ${error.message}\nPlease check if you're logged in and try again.`
        : 'Failed to upload media. Please try again.';
        
      Alert.alert(
        'Upload Failed',
        errorMessage
      );
    }
  };

  return (
    <View style={styles.container}>
      <MediaUploadModal
        visible={isModalVisible}
        onClose={handleCloseModal}
        onSubmit={handleUpload}
      />
      <TouchableOpacity style={styles.floatingButton} onPress={handleCameraPress}>
        <Ionicons name="camera" size={30} color="white" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'absolute',
    bottom: 20,
    right: 20,
  },
  floatingButton: {
    backgroundColor: '#6200ee',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default FloatingButton;