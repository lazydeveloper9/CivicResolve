// src/components/Header.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from 'react-native-vector-icons/Ionicons';

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title}) => {
  return (
    <SafeAreaView style= { {backgroundColor: '#6200ee',height:1,} }>
    <View style={styles.header}>
      <Text style={styles.headerText}>{title}</Text>
      <TouchableOpacity style={styles.menuButton} onPress={() => console.log('Menu button pressed')}>
        <Ionicons name="menu" size={30} color="white" />
      </TouchableOpacity>
    </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  header: {
    width: '100%',
    height: 40,
    backgroundColor: '#6200ee',
    flexDirection: 'row',
    // justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  headerText: {
    color: 'white',
    // height:40,
    paddingLeft: 10,
    fontSize: 20,
    fontWeight: 'bold',
  },
  menuButton: {
    position: 'absolute',
    right: 10,
  },
});

export default Header;