// MediaListScreen.tsx
import React, { useState, useEffect, useCallback } from 'react';
import { FlatList, StyleSheet, Text, View, ActivityIndicator } from 'react-native';
// import { SafeAreaView } from 'react-native-safe-area-context';
import MediaCard from './MediaCard';
// import FloatingButton from './FloatingButton';

// 🛑 IMPORTANT: Replace this with your computer's actual IP address!
const SERVER_URL = 'http://10.11.231.68:3000/api/media';
const POLLING_INTERVAL = 3000; // Check every 3 seconds

interface MediaItem {
  name: string;
  path: string;
  url: string;
  type: 'image' | 'video';
  description: string;
  location: string;
  datetime: string;
  contributor: string;
  issue_type?: string;
  issueType?: string;
}

const MediaListScreen = () => {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadMedia = useCallback(async () => {
    try {
      console.log('Fetching media from:', SERVER_URL);
      const response = await fetch(SERVER_URL);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      console.log('Received media data:', data);

      // Map issue_type to issueType for each item
      const mappedData = data.map((item: any) => ({
        ...item,
        issueType: item.issue_type,
      }));

      setMedia(mappedData.sort((a: MediaItem, b: MediaItem) =>
        new Date(b.datetime).getTime() - new Date(a.datetime).getTime()
      ));
      setError(null); // Clear any previous errors
      
    } catch (err) {
      console.error('Error fetching media:', err);
      setError('Failed to connect to the media server. Is it running? Is the IP correct?');
    } finally {
      setIsLoading(false);
    }
  }, [media.length]); // Dependency helps avoid re-creating the function unnecessarily

  // --- Effect for initial load ---
  useEffect(() => {
    loadMedia();
  }, []); // Run only once on mount

  // --- Effect for AUTOMATIC REFRESH (Polling the server) ---
  useEffect(() => {
    // Initial load
    loadMedia();

    // Set up polling
    const interval = setInterval(() => {
      console.log('Polling server for new media...');
      loadMedia();
    }, POLLING_INTERVAL);

    return () => clearInterval(interval); // Cleanup on unmount
  }, [loadMedia]);


  if (isLoading) {
    return <ActivityIndicator size="large" style={styles.centered}/>;
  }

  if (error) {
    return <Text style={[styles.centered, styles.errorText]}>{error}</Text>;
  }

  return (
    <View style={styles.container}>
      {media.length === 0 ? (
        <Text style={styles.centered}>No media found on the server.</Text>
      ) : (
        <FlatList
          data={media}
          renderItem={({ item }: { item: MediaItem }) => <MediaCard item={item} />}
          keyExtractor={(item: MediaItem) => item.url}
          numColumns={1}
          contentContainerStyle={styles.list}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: '100%',
    flex: 1,
    flexDirection:'column',
    backgroundColor: '#f0f0f0',
  },
  list: {
    justifyContent: 'center',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  errorText: {
    color: 'red',
  }
});

export default MediaListScreen;