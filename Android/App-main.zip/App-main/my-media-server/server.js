// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const multer = require('multer');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 3000;
const uploadsDir = path.join(__dirname, 'public', 'media');

// --- PostgreSQL Database Setup ---
// ⚠️ Replace with your actual PostgreSQL credentials
const pool = new Pool({
  user: 'postgres', // or your user
  host: 'localhost',
  database: 'media_app_db', // the database you created
  password: 'rootyogendra', // 🚨 Change this!
  port: 5432,
});

const createTables = async () => {
  const client = await pool.connect();
  try {
    // Create users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    // Add name and age columns if they don't exist
    await client.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(255)');
    await client.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS age INTEGER');

    // Create media table
    await client.query(`
      CREATE TABLE IF NOT EXISTS media (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL,
        description TEXT,
        location VARCHAR(255),
        city_name VARCHAR(255) NOT NULL,
        issue_type VARCHAR(50),
        datetime TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    console.log('✅ "users" table is successfully created or already exists.');
  } finally {
    client.release();
  }
};

// Initialize tables on server start
createTables().catch(err => console.error('Error creating tables on startup', err));


// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// --- Middlewares ---
app.use(cors()); // Allow requests from your React Native app
app.use(express.json()); // To parse JSON request bodies
// Serve static files (images, videos) from the 'public' directory
app.use(express.static('public'));

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

  if (token == null) {
    return res.sendStatus(401); // if there's no token
  }

  jwt.verify(token, 'your_jwt_secret', (err, payload) => {
    if (err) {
      return res.sendStatus(403); // if the token is invalid
    }
    req.user = payload.user;
    next();
  });
};


// Set up storage for multer
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
  }
});

const upload = multer({ storage });

app.post('/upload', authenticateToken, upload.single('media'), async (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  try {
    console.log('Received file:', req.file);
    console.log('Received body:', req.body);
    console.log('User:', req.user);

    console.log('Request body contents:', req.body);  // Add this line to see full request body
    
    const mediaDetails = {
      filename: req.file.filename,
      filepath: req.file.path.replace(/\\/g, '/'), // Convert Windows path to Unix style
      type: req.file.mimetype.startsWith('image/') ? 'image' : 'video',
      description: req.body.description || '',
      location: req.body.location || '',
      city_name: req.body.location || 'Unknown', // Use location as city_name or default to Unknown
      issue_type: req.body.issueType || 'others',
      datetime: req.body.datetime ? new Date(req.body.datetime).toISOString() : new Date().toISOString(),
      user_id: req.user.id
    };
    
    console.log('Issue Type from request:', req.body.issueType);  // Add this line to specifically see issueType

    console.log('Preparing to save media details:', mediaDetails);

    // First check if the media table exists and ensure issue_type column exists
    await pool.query('ALTER TABLE media ADD COLUMN IF NOT EXISTS issue_type VARCHAR(50)');
    
    const tableCheck = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'media'
      );
    `);

    if (!tableCheck.rows[0].exists) {
      console.log('Media table does not exist, creating it...');
      await pool.query(`
        CREATE TABLE IF NOT EXISTS media (
          id SERIAL PRIMARY KEY,
          filename VARCHAR(255) NOT NULL,
          filepath VARCHAR(255) NOT NULL,
          type VARCHAR(50) NOT NULL,
          description TEXT,
          location VARCHAR(255),
          issue_type VARCHAR(50),
          datetime TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          user_id INTEGER REFERENCES users(id),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
    }

    // Save media details to database
    const result = await pool.query(
      `INSERT INTO media (filename, filepath, type, description, location, city_name, issue_type, datetime, user_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id`,
      [
        mediaDetails.filename,
        mediaDetails.filepath,
        mediaDetails.type,
        mediaDetails.description,
        mediaDetails.location,
        mediaDetails.city_name,
        mediaDetails.issue_type,
        mediaDetails.datetime,
        mediaDetails.user_id
      ]
    );

    console.log('Media saved successfully with ID:', result.rows[0].id);

    res.json({
      message: 'File uploaded successfully',
      mediaId: result.rows[0].id,
      details: mediaDetails
    });
  } catch (error) {
    console.error('Detailed error saving media:', error);
    
    // Send more detailed error information
    res.status(500).json({ 
      error: 'Failed to save media details',
      details: error.message,
      code: error.code
    });
  }
});

// --- Profile Route ---
app.get('/api/profile', authenticateToken, async (req, res) => {
  try {
    console.log('Fetching profile for user:', req.user);
    const userResult = await pool.query('SELECT id, email, name, age FROM users WHERE id = $1', [req.user.id]);
    console.log('Query result:', userResult.rows);
    
    if (userResult.rows.length === 0) {
      console.log('No user found with id:', req.user.id);
      return res.status(404).json({ error: 'User not found.' });
    }
    res.json(userResult.rows[0]);
  } catch (err) {
    console.error('Profile fetch error:', err);
    console.error('Stack trace:', err.stack);
    res.status(500).json({ 
      error: 'Server error while fetching profile.',
      details: err.message,
      stack: err.stack
    });
  }
});


// --- Media Routes ---
app.get('/api/media', async (req, res) => {
  try {
    // Get files from the filesystem
    const mediaDir = path.join(__dirname, 'public', 'media');
    let files = [];
    try {
      files = fs.readdirSync(mediaDir);
    } catch (err) {
      console.error('Error reading media directory:', err);
    }

    // Get media entries from database
    const result = await pool.query(`
      SELECT m.*, u.name as contributor
      FROM media m
      LEFT JOIN users u ON m.user_id = u.id
      ORDER BY m.created_at DESC
    `);
    
    console.log('Database entries:', result.rows);

    // Combine database entries with filesystem files
    const mediaItems = files.map(filename => {
      // Find matching database entry
      const dbEntry = result.rows.find(row => row.filename === filename);
      const fileExtension = path.extname(filename).toLowerCase();
      
      return {
        id: dbEntry?.id || null,
        name: filename,
        path: `/media/${filename}`,
        url: `${req.protocol}://${req.get('host')}/media/${filename}`,
        type: dbEntry?.type || (['.jpg', '.jpeg', '.png', '.gif'].includes(fileExtension) ? 'image' : 
              ['.mp4', '.mov', '.avi'].includes(fileExtension) ? 'video' : 'file'),
        description: dbEntry?.description || '',
        location: dbEntry?.location || '',
        datetime: dbEntry?.datetime || new Date().toISOString(),
        contributor: dbEntry?.contributor || 'Anonymous',
        issue_type: dbEntry?.issue_type || 'others'
      };
    });

    console.log(`Found ${mediaItems.length} media items`);
    res.json(mediaItems);
  } catch (error) {
    console.error('Error fetching media:', error);
    res.status(500).json({ error: 'Failed to list media files' });
  }
});

// --- NEW LOCATION ENDPOINT ---
app.post('/api/location', authenticateToken, async (req, res) => {
  const { cityName } = req.body;
  const userId = req.user.id; // From our authenticateToken middleware

  if (!cityName) {
    return res.status(400).json({ error: 'City name is required.' });
  }

  try {
    const newLocation = await pool.query(
      'INSERT INTO user_locations (city_name, user_id) VALUES ($1, $2) RETURNING *',
      [cityName, userId]
    );

    console.log(`Saved location '${cityName}' for user ID ${userId}`);
    res.status(201).json({ 
      success: true, 
      message: 'Location saved successfully.',
      data: newLocation.rows[0] 
    });
  } catch (error) {
    console.error('Error saving location to database:', error);
    res.status(500).json({ error: 'Server error while saving location.' });
  }
});
// --- END OF NEW LOCATION ENDPOINT ---

// --- Authentication Routes ---

// SIGNUP
app.post('/api/auth/signup', async (req, res) => {
  const { email, password, name, age } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    const newUser = await pool.query(
      'INSERT INTO users (email, password_hash, name, age) VALUES ($1, $2, $3, $4) RETURNING id, email, name, age',
      [email, password_hash, name, age]
    );

    res.status(201).json(newUser.rows[0]);
  } catch (err) {
    console.error(err.message);
    // Check for unique constraint violation (duplicate email)
    if (err.code === '23505') {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }
    res.status(500).json({ error: 'Server error during signup.' });
  }
});

// LOGIN
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const userResult = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (userResult.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const user = userResult.rows[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    // Create JWT
    const payload = { user: { id: user.id, email: user.email } };
    const token = jwt.sign(payload, 'your_jwt_secret', { expiresIn: '1h' }); // Use an environment variable for the secret!

    res.json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Server error during login.' });
  }
});


// Debug endpoint to check database tables
app.get('/api/debug/tables', async (req, res) => {
  try {
    const tables = await pool.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema='public';
    `);
    
    const mediaTable = await pool.query(`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'media';
    `);

    res.json({
      tables: tables.rows,
      mediaColumns: mediaTable.rows
    });
  } catch (error) {
    console.error('Debug endpoint error:', error);
    res.status(500).json({ error: error.message });
  }
});

// --- Start the server ---
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Media server is running on port ${PORT}`);
  console.log(`➡️  Make sure to use your network IP address in your React Native app!`);
  console.log(`🔍 Debug endpoint available at http://localhost:${PORT}/api/debug/tables`);
});
